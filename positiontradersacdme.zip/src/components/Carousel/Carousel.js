import React from 'react'

const Carousel = () => {
  return (
    <div>Carousel</div>
  )
}

export default Carousel